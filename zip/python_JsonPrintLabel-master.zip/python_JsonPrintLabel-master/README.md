# python_JsonPrintLabel

This little python script generate a pdf format envelope with addresses got from a json parsing

The json is provided by Regione Lombardia opendata website (https://www.dati.lombardia.it/)

##Components / dependency:
   pip install fpdf


##Ho use it

git clone https://github.com/pierangelo1982/python_JsonPrintLabel.git

cd python_JsonPrintLabel

python parserlabel.py


##
