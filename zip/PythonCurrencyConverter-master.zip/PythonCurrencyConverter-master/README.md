PythonCurrencyConverter
=======================

currency converter in Python, with currency value updated by a feed from European Central Bank website

<H3>Request</h3>
It's necessary install feedparser (pip install feedparser)
