# KMLcolor
script python for changing colour and marker in a kml file

#dependencies
##lxml
pip install lxml

PyKML
import pykml

