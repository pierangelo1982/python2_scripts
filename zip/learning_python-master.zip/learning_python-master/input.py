import os

#input
a = input("Inserisci un numero: ")
b = input("inserisci un altro numero: ")
print a + b


#input string
a = raw_input("il tuo nome? ")
b = raw_input("il tuo cognome? ")
print "ciao ", a, b